#pragma once

struct man
{
	char Fio[50];
	char gender[10];
	int age;
	char work[50];
	long long int zarplata;
	char tsel[10];



};

struct queue_elem
{
	man client;
	queue_elem* next = nullptr;
	queue_elem* prev = nullptr;
};

struct queue
{
	queue_elem* first = nullptr;
	queue_elem* last = nullptr;
	size_t size = 0;
};

void		enqueue(queue& q, man employee); 
bool		dequeue(queue& q, man& employee);
void		clear(queue& q);