#pragma once


void task1_1();

void task2_1();

void task3_1();


void task1_2();

void task2_2();

void task3_2();