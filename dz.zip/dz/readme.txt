2_lesson is about
Стек
3_lesson is about
Очередь

4_lesson is about
Односвязный список

5_lesson is about
Двусвязный список